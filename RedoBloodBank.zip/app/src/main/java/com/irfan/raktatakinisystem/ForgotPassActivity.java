package com.irfan.raktatakinisystem;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPassActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextInputEditText email = findViewById(R.id.emailLoginForgot);
        setContentView(R.layout.activity_forgot_pass);
        findViewById(R.id.resetForgot).setOnClickListener(view -> {
                 if(email.getText().toString().isEmpty()){
                     email.setError("Please enter email");
                 }else{
                     email.setError("");
                     FirebaseAuth.getInstance().sendPasswordResetEmail(email.getText().toString()).addOnFailureListener(e -> Toast.makeText(ForgotPassActivity.this, "Try Again.", Toast.LENGTH_SHORT).show()).addOnSuccessListener(aVoid -> Toast.makeText(ForgotPassActivity.this, "Password Reset link Sent.", Toast.LENGTH_LONG).show());
                 }
        });
    }
}