package com.irfan.raktatakinisystem.listeners;

import android.view.View;

public interface MyOnClickListener {
    void getPosition(int position);
}
